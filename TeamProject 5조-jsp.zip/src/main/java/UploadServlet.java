import java.io.File;
import java.io.IOException;
import java.util.List;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import org.apache.commons.fileupload.FileItem;
import org.apache.commons.fileupload.disk.DiskFileItemFactory;
import org.apache.commons.fileupload.servlet.ServletFileUpload;

	@WebServlet("/uploadServlet")
	public class UploadServlet extends HttpServlet {
	    private static final long serialVersionUID = 1L;
	    private static final String UPLOAD_DIRECTORY = "resources/projectImg";

	    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
	        if (!ServletFileUpload.isMultipartContent(request)) {
	            response.getWriter().println("Error: Form must has enctype=multipart/form-data.");
	            response.getWriter().flush();
	            return;
	        }

	        DiskFileItemFactory factory = new DiskFileItemFactory();
	        ServletFileUpload upload = new ServletFileUpload(factory);

	        try {
	            List<FileItem> formItems = upload.parseRequest(request);
	            if (formItems != null && formItems.size() > 0) {
	                for (FileItem item : formItems) {
	                    if (!item.isFormField()) {
	                        String fileName = new File(item.getName()).getName();
	                        String filePath = getServletContext().getRealPath("") + File.separator + UPLOAD_DIRECTORY + File.separator + fileName;
	                        File storeFile = new File(filePath);
	                        item.write(storeFile);
	                        request.setAttribute("message", "File uploaded successfully: " + fileName);
	                    } else {
	                        // Handle other form fields
	                        String fieldName = item.getFieldName();
	                        String fieldValue = item.getString();
	                        if ("playerName".equals(fieldName)) {
	                            request.setAttribute("playerName", fieldValue);
	                        }
	                    }
	                }
	            }
	        } catch (Exception ex) {
	            request.setAttribute("message", "There was an error: " + ex.getMessage());
	        }
	        getServletContext().getRequestDispatcher("/main.jsp").forward(request, response);
	    }
	}


